
#include <stdio.h>

int main(int argc, char **argv)
{
	printf("Hello AGL!\n");

	return 0;
}

